AOS.init({
    offset: 200,
    duration: 1200,
});